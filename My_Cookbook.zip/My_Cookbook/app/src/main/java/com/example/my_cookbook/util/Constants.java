package com.example.my_cookbook.util;

public class Constants {

    public static final String BASE_URL = "https://www.food2fork.com";
    public static final int NETWORK_TIMEOUT = 3000;

    public static final String API_KEY = "2d527433ae8a3a9957f241fb66c43a2d"; //Use differet API key as food2fork provides limited query search per day and it might just run out
}
