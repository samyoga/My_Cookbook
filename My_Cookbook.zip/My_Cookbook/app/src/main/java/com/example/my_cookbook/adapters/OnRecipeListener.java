package com.example.my_cookbook.adapters;

public interface OnRecipeListener {

    void onRecipeClick(int position);

    void onCategoryClick(String category);
}
