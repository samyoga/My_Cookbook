# My_Cookbook
Food recipes collection application in android that implements REST API using MVVM architecture.
